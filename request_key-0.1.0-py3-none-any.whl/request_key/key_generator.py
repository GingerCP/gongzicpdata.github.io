import hashlib
import logging
from urllib.parse import urlencode

def generate_request_key(query_params, timestamp, nonce, imei, version, extra_data):
    """
    生成请求签名的唯一 Key，基于 SHA-256 哈希算法。

    参数:
        query_params (dict): 需要编码的 URL 查询参数（字典格式）。
        timestamp (str/int): 时间戳，可为字符串或整数。
        nonce (str): 随机数，防止重放攻击。
        imei (str): 设备唯一标识（IMEI）。
        version (str): API 版本或应用版本。
        extra_data (str): 额外的参数，可以为空字符串。

    返回:
        str: 生成的 32 位哈希 key（SHA-256 截取）。
    """

    try:
        # 确保参数为字符串
        timestamp = str(timestamp)
        nonce = str(nonce)
        imei = str(imei)
        version = str(version)
        extra_data = str(extra_data)

        # 确保 query_params 是字典
        if not isinstance(query_params, dict):
            logging.error("query_params 必须是一个字典")
            raise ValueError("query_params 必须是一个字典")

        # 排序并转换为 URL 编码格式
        sorted_params = urlencode(sorted(query_params.items()), doseq=True)

        # 生成签名字符串
        sign_text = f"{sorted_params}{timestamp}{nonce}{imei}{version}{extra_data}"

        # 计算 SHA-256 哈希
        sha256_hash = hashlib.sha256(sign_text.encode('utf-8')).hexdigest()

        # 取中间 32 位
        return sha256_hash[10:42]

    except Exception as e:
        logging.error(f"生成请求 Key 时出错: {e}")
        return None
